$("#inicio").on("click",function(){
   $("p").html("<strong>bienvenido a inicio</strong>");
});


$("#dashboard").on("click",function(){
    $("p").html("<strong>bienvenido a dashboard</strong>");
 });


 /*$("#iniciar").on("click",function(){
    $("p").html("<strong>bienvenido a iniciar</strong>");
 });*/

